package com.example.smith.swipe;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class ProfileFragment extends Fragment {
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;
    FirebaseStorage firebaseStorage;
    FloatingActionButton editFab;
    private ImageView imageView, gender;
    StorageReference storageReference, myStorageRef;
    private TextView name, age, info, major, intro;
    View infoborder, introborder;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.activity_profile, null);
    }

    @Override
    public void onViewCreated(@NonNull final View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        editFab = view.findViewById(R.id.editFab);
        imageView = view.findViewById(R.id.matches_icon);
        name = view.findViewById(R.id.name);
        age = view.findViewById(R.id.age);
        gender = view.findViewById(R.id.gender);
        major = view.findViewById(R.id.major);

        introborder = view.findViewById(R.id.introborder);
        intro = view.findViewById(R.id.intro);

        infoborder = view.findViewById(R.id.infoborder);
        info = view.findViewById(R.id.info);

        editFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), EditProfile.class));
            }
        });

        mAuth = FirebaseAuth.getInstance();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();
        DatabaseReference myRef = db.child("users").child(mAuth.getCurrentUser().getUid());
        DatabaseReference aRef = db.child("users").child(mAuth.getCurrentUser().getUid()).child("anthem");
        firebaseStorage = FirebaseStorage.getInstance();

        storageReference = firebaseStorage.getReference();
        /*storageReference.child(mAuth.getUid()).child("images").child("image1").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {
                Picasso.get().load(uri).into(imageView);
            }
        });*/

        Button signOut = view.findViewById(R.id.signOut);
        signOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getActivity(), Login.class));
            }
        });

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Info i = dataSnapshot.getValue(Info.class);

                Picasso.get().load(i.getProfilePic()).into(imageView);

                name.setText(i.getFirstName());

                if(i.getGender().equals("Male")){
                    gender.setImageResource(R.drawable.male2);
                } else {
                    gender.setImageResource(R.drawable.female2);
                }

                age.setText(i.getAge());

                if(i.getCourseCode()==null || i.getCourseCode().equals("")){
                    major.setVisibility(View.GONE);
                }else{
                    major.setText(i.getCourseCode());
                    major.setVisibility(View.VISIBLE);
                }

                if(i.getIntro()==null || i.getIntro().equals("")){
                    intro.setVisibility(View.GONE);
                    introborder.setVisibility(View.GONE);
                }else{
                    intro.setText(i.getIntro());
                    intro.setVisibility(View.VISIBLE);
                    introborder.setVisibility(View.VISIBLE);
                }

                if(i.getAboutMe()==null || i.getAboutMe().equals("")){
                    info.setVisibility(View.GONE);
                    infoborder.setVisibility(View.GONE);
                }else{
                    info.setText(i.getAboutMe());
                    info.setVisibility(View.VISIBLE);
                    infoborder.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
