package com.example.smith.swipe;

import android.app.Activity;
import android.content.Intent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class SwipeStackAdapter extends BaseAdapter {

    private List<Info> mData;
    private Activity activity;

    public SwipeStackAdapter(Activity activity, ArrayList<Info> data) {
        this.activity = activity;
        this.mData = data;
    }

    @Override
    public int getCount() {
        return mData.size();
    }

    @Override
    public Info getItem(int position) {
        return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = activity.getLayoutInflater().inflate(R.layout.card1, parent, false);
        }

        View viewInfo = convertView.findViewById(R.id.view22);
        final View finalConvertView = convertView;
        viewInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent intent = new Intent(finalConvertView.getContext(), other_profile.class);
                intent.putExtra("id", mData.get(position).getId());
                finalConvertView.getContext().startActivity(intent);
            }
        });

        TextView textViewCard = (TextView) convertView.findViewById(R.id.name);
        textViewCard.setText(mData.get(position).getFirstName());

        ImageView pic = convertView.findViewById(R.id.pic);
        Picasso.get().load(mData.get(position).getProfilePic()).into(pic);

        TextView age = convertView.findViewById(R.id.age);
        age.setText(mData.get(position).getAge());

        ImageView gender = convertView.findViewById(R.id.gender);
        if(mData.get(position).getGender().equals("Male")){
            gender.setImageResource(R.drawable.male2);
        } else {
            gender.setImageResource(R.drawable.female2);
        }

        TextView info = convertView.findViewById(R.id.info);

        if(mData.get(position).getIntro()==null){
            info.setVisibility(View.GONE);
        } else {
            info.setVisibility(View.VISIBLE);
            info.setText(mData.get(position).getIntro());
        }

        return convertView;
    }
}
