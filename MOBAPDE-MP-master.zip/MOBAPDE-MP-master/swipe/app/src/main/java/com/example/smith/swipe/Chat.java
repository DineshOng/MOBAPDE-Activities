package com.example.smith.swipe;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceActivity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.NavUtils;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Queue;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Chat extends AppCompatActivity {
    private EditText editText;
    private MessageAdapter messageAdapter;
    private ListView messagesView;
    private TextView textView;

    DatabaseReference db;
    DatabaseReference myRef;

    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    ArrayList<String> ids;

    APIService apiService;

    boolean notify = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.chat);
        //setupActionBar();
        ids = new ArrayList<String>();
        //getSupportActionBar().setDisplayShowHomeEnabled(true);
        //getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        //getSupportActionBar().setDisplayUseLogoEnabled(true);
        //getSupportActionBar().setIcon(R.mipmap.ic_launcher);

        //Toolbar tb = findViewById(R.id.toolbar);

        db = FirebaseDatabase.getInstance().getReference();
        myRef = db.child("users");
        mAuth = FirebaseAuth.getInstance();

        apiService = Client.getClient("https://fcm.googleapis.com/").create(APIService.class);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayUseLogoEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(false);
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowHomeEnabled(false);

        ActionBar.LayoutParams lp1 = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.MATCH_PARENT);
        View customNav = LayoutInflater.from(this).inflate(R.layout.toolbar, null); // layout which contains your button.
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.WHITE));
        actionBar.setCustomView(customNav, lp1);

        ImageView back = customNav.findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        CircularImageView icon = customNav.findViewById(R.id.icon);
        Picasso.get().load(getIntent().getStringExtra("image")).into(icon);

        textView = customNav.findViewById(R.id.name);
        textView.setText(getIntent().getStringExtra("name"));

        editText = (EditText) findViewById(R.id.editText);

        messageAdapter = new MessageAdapter(this, getIntent().getStringExtra("image"));
        messagesView = (ListView) findViewById(R.id.messages_view);
        messagesView.setAdapter(messageAdapter);

        loadMessages();
    }

    public void loadMessages() {
        db.child("messages").child(getIntent().getStringExtra("chatid")).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Log.d("zxcv", dataSnapshot.child("message").getValue()+"");
                Log.d("zxcv", dataSnapshot.child("senderID").getValue()+" 4");
                Log.d("zxcv", dataSnapshot.child("timestamp").getValue()+" 5");
                Log.d("zxcv", dataSnapshot.child("message").getValue()+"");
                Log.d("zxcv", dataSnapshot.getChildrenCount()+"");
                //Message message = null;
                //for (DataSnapshot data: dataSnapshot.getChildren()) {
                    String senderID = dataSnapshot.child("senderID").getValue()+"";
                    if(senderID.equals(mAuth.getUid())) {
                        final Message message = new Message(dataSnapshot.child("message").getValue()+"", textView.getText().toString(), getIntent().getStringExtra("image"), true);
                        messageAdapter.add(message);
                        messagesView.setSelection(messagesView.getCount() - 1);
                    } else {
                        final Message message = new Message(dataSnapshot.child("message").getValue()+"", null, null, false);
                        messageAdapter.add(message);
                        messagesView.setSelection(messagesView.getCount() - 1);
                    }
                //}
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void sendMessage(View view) {
        String message = editText.getText().toString().trim();
        notify = true;
        if (!message.equals("")) {
            boolean belongsToCurrentUser = true;
            final Message message1 = new Message(message, null, null, belongsToCurrentUser);
            String id = db.child("messages").child(getIntent().getStringExtra("chatid")).push().getKey();
            db.child("messages").child(getIntent().getStringExtra("chatid")).child(id).setValue(new MessageModel(message, mAuth.getUid(), System.currentTimeMillis()+""));
            //messageAdapter.add(message1);
            //messagesView.setSelection(messagesView.getCount() - 1);
            //ids = MessagesFragment.getIds();
            //ids.remove(getIntent().getStringExtra("chatid"));
            //ids.add(getIntent().getStringExtra("chatid"));
            db.child("matches").child(mAuth.getUid()).child(getIntent().getStringExtra("chatid")).child("lastMessageID").setValue(message);
            db.child("matches").child(getIntent().getStringExtra("chatwith")).child(getIntent().getStringExtra("chatid")).child("lastMessageID").setValue(message);
            db.child("matches").child(mAuth.getUid()).child(getIntent().getStringExtra("chatid")).child("lastMessageUser").setValue(mAuth.getUid());
            db.child("matches").child(getIntent().getStringExtra("chatwith")).child(getIntent().getStringExtra("chatid")).child("lastMessageUser").setValue(mAuth.getUid());
            //Collections.reverse(ids);
            db.child("recentMessages").child(mAuth.getUid()).setValue(ids);
            final String msg = message;
            if(notify)
                sendNotification(getIntent().getStringExtra("chatwith"), mAuth.getUid(), msg);
            notify = false;

            editText.getText().clear();
        }
    }

    private void sendNotification(final String chatwith, final String uid, final String msg) {
        db.child("Tokens").child(chatwith).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("zxcv", dataSnapshot.child("token").getValue()+"");
                final Token token = new Token(dataSnapshot.child("token").getValue()+"");
                db.child("basic").child(mAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Data data =  new Data(mAuth.getUid(), R.mipmap.ic_launcher, msg, "New Message from "+dataSnapshot.child("firstName").getValue(), chatwith);
                        Sender sender = new Sender(data, token.getToken());
                        apiService.sendNotification(sender)
                                .enqueue(new Callback<MyResponse>() {
                                    @Override
                                    public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                                        if(response.code()==200){
                                            if(response.body().success!=1){

                                            }
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<MyResponse> call, Throwable t) {

                                    }
                                });
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
