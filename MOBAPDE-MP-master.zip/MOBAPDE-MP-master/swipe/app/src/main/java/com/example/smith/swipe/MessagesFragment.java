package com.example.smith.swipe;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

import java.util.ArrayList;

public class MessagesFragment extends Fragment {
    private RecyclerView messagesRecyclerArea, matchesRecyclerArea;
    private MessagesAdapter messagesAdapter;
    private MatchesAdapter matchesAdapter;

    DatabaseReference db;
    DatabaseReference myRef;

    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    String name;
    String pic;

    private static ArrayList<String> ids;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.activity_messages, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        ids = new ArrayList<String>();
        name = "";  pic = "";

        db = FirebaseDatabase.getInstance().getReference();
        myRef = db.child("users");
        mAuth = FirebaseAuth.getInstance();

        //(1) The RecyclerView is where the recycling will be done. In this case, this has already
        //    been declared in the activity_main.xml
        messagesRecyclerArea = view.findViewById(R.id.messages_recycler_area);

        //(2) The LinearLayoutManager is in-charge of the layout of the RecyclerView
        messagesRecyclerArea.setLayoutManager(new LinearLayoutManager(getActivity()));

        //(3) The RecyclerView.Adapter manages the internal content of the RecyclerView
        messagesAdapter = new MessagesAdapter(getActivity());
        messagesRecyclerArea.setAdapter(messagesAdapter);

        //(1) The RecyclerView is where the recycling will be done. In this case, this has already
        //    been declared in the activity_main.xml
        matchesRecyclerArea = view.findViewById(R.id.matches_recycler_area);

        //(2) The LinearLayoutManager is in-charge of the layout of the RecyclerView
        matchesRecyclerArea.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));

        //(3) The RecyclerView.Adapter manages the internal content of the RecyclerView
        matchesAdapter = new MatchesAdapter(getActivity());
        matchesRecyclerArea.setAdapter(matchesAdapter);

        //LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false);
        //layoutManager.setReverseLayout(true);
        //layoutManager.setStackFromEnd(true);
        //matchesRecyclerArea.setLayoutManager(layoutManager);

        db.child("matches").child(mAuth.getUid()).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                final String r = dataSnapshot.child("receiverID").getValue()+"";
                final String m = dataSnapshot.child("lastMessageID").getValue()+"";
                final String id = dataSnapshot.getKey();
                if(!ids.contains(id) && !m.equals(""))
                    ids.add(id);
                matchesAdapter.addItem(id, r);
                db.child("messages").child(id).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()) {
                            messagesAdapter.addItem(id, r);
                            db.child("messages").child(id).removeEventListener(this);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        TextView d = view.findViewById(R.id.messages);
        TextView addMatch = view.findViewById(R.id.addMatch);
        TextView addMessage = view.findViewById(R.id.addMessage);

        ConstraintLayout.LayoutParams cp = (ConstraintLayout.LayoutParams)d.getLayoutParams();
        cp.setMargins(48, getStatusBarHeight(), 0, 24);
        cp = (ConstraintLayout.LayoutParams)addMatch.getLayoutParams();
        cp.setMargins(52, 24, 0, 0);
        cp = (ConstraintLayout.LayoutParams)matchesRecyclerArea.getLayoutParams();
        cp.setMargins(52, 24, 0, 0);
        cp = (ConstraintLayout.LayoutParams)addMessage.getLayoutParams();
        cp.setMargins(52, 48, 0, 0);
        cp = (ConstraintLayout.LayoutParams)messagesRecyclerArea.getLayoutParams();
        cp.setMargins(52, 24, 0, 0);




        /*db.child("matches").child(mAuth.getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot data: dataSnapshot.getChildren()) {
                    String r = data.child("receiverID").getValue() + "";
                    String m = data.child("lastMessageID").getValue() + "";
                    String id = data.getKey();
                    if (!m.equals("")) {
                        messagesAdapter.addItem(id, r);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/

        updateToken(FirebaseInstanceId.getInstance().getToken());
    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private void updateToken(String token){
        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("Tokens");
        Token token1 = new Token(token);
        reference.child(mAuth.getUid()).setValue(token1);
    }

    public static ArrayList<String> getIds(){
        return  ids;
    }
}
