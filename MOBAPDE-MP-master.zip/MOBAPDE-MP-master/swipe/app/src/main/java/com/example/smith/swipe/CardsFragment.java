package com.example.smith.swipe;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Collections;

import link.fls.swipestack.SwipeStack;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CardsFragment extends Fragment implements SwipeStack.SwipeStackListener, View.OnClickListener {
    private ImageButton like, nope;
    private ArrayList<Info> mData;
    private ArrayList<String> done, likedBy;
    private SwipeStack mSwipeStack;
    private SwipeStackAdapter mAdapter;
    private Info myInfo;

    DatabaseReference db;

    APIService apiService;

    boolean notify = false;

    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //return super.onCreateView(inflater, container, savedInstanceState);
        return inflater.inflate(R.layout.activity_cards1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mSwipeStack = view.findViewById(R.id.swipeStack);

        like = view.findViewById(R.id.like);
        nope = view.findViewById(R.id.nope);

        like.setOnClickListener(this);
        nope.setOnClickListener(this);

        mData = new ArrayList<Info>();
        done = new ArrayList<String>();
        likedBy = new ArrayList<String>();
        mAdapter = new SwipeStackAdapter(getActivity(), mData);
        mSwipeStack.setAdapter(mAdapter);
        mSwipeStack.setListener(this);

        db = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        apiService = Client.getClient("https://fcm.googleapis.com/").create(APIService.class);

        getActivity().getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getActivity().getWindow().setStatusBarColor(Color.TRANSPARENT);

        TextView d = view.findViewById(R.id.messages);

        ConstraintLayout.LayoutParams cp = (ConstraintLayout.LayoutParams)d.getLayoutParams();
        cp.setMargins(48, getStatusBarHeight(), 0, 0);
        //d.setLayoutParams(cp);

        //RelativeLayout.LayoutParams relativeParams = (RelativeLayout.LayoutParams)d.getLayoutParams();
        //relativeParams.setMargins(48, getStatusBarHeight()+28, 0, 0);  // left, top, right, bottom
        //d.setLayoutParams(relativeParams);

        //relativeParams = (RelativeLayout.LayoutParams)mSwipeStack.getLayoutParams();
        //relativeParams.setMargins(0, 0, 0, 0);
        //mSwipeStack.setLayoutParams(relativeParams);

        initLogs();

        fillData();

        initLikedBy();

        initMyInfo();
    }

    public void initLogs(){
        db.child("logs").child(mAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data: dataSnapshot.getChildren()) {
                    if(!done.contains(data.getKey()))
                        done.add(data.getKey());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void initLikedBy(){
        db.child("likes").child(mAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data: dataSnapshot.getChildren()) {
                    if(!likedBy.contains(data.getKey()))
                        likedBy.add(data.getKey());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void initMyInfo(){
        db.child("users").child(mAuth.getUid()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                myInfo = dataSnapshot.getValue(Info.class);
                myInfo.setId(dataSnapshot.getKey());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    private void fillData() {
        db.child("basic").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Info info = null;
                //Anthem anthem = null;
                if(!(dataSnapshot.getKey()+"").equals(mAuth.getCurrentUser().getUid()) && !done.contains(dataSnapshot.getKey())) {
                    Log.d("TAG", dataSnapshot.child("firstName").getValue()+"");
                    info = dataSnapshot.getValue(Info.class);
                    info.setId(dataSnapshot.getKey());
                    //anthem = dataSnapshot.child("anthem").getValue(Anthem.class);
                    //info.setAnthem(anthem);
                    mData.add(info);
                }
                mAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onClick(View v) {
        if (v.equals(nope)) {
            mSwipeStack.swipeTopViewToLeft();
        } else if (v.equals(like)) {
            mSwipeStack.swipeTopViewToRight();
        }
    }

    @Override
    public void onViewSwipedToRight(int position) {
        String swipedElement = mAdapter.getItem(position).getId();
        String id = "";
        if(likedBy.contains(mAdapter.getItem(position).getId())) {
            notify = true;
            id = db.child("users").child(mAuth.getUid()).child("matches").push().getKey();
            db.child("matches").child(mAuth.getUid()).child(id).child("receiverID").setValue(mAdapter.getItem(position).getId());
            db.child("matches").child(mAdapter.getItem(position).getId()).child(id).child("receiverID").setValue(mAuth.getUid());
            //db.child("matches").child(mAuth.getUid()).child(id).child("lastMessageID").setValue("");
            //db.child("matches").child(mAdapter.getItem(position).getId()).child(id).child("lastMessageID").setValue("");
            db.child("pendingPopups").child(mAdapter.getItem(position).getId()).child(mAuth.getUid()).setValue(1);
            if(notify)
                sendNotification(mAdapter.getItem(position).getId(), mAuth.getUid(), "");
            notify = false;
            inputDialog(id, mAdapter.getItem(position).getFirstName(), mAdapter.getItem(position).getProfilePic(), mAdapter.getItem(position).getId());
        }
        db.child("logs").child(mAuth.getUid()).child(mAdapter.getItem(position).getId()).setValue("like");
        db.child("likes").child(mAdapter.getItem(position).getId()).child(mAuth.getUid()).setValue(1);

        Toast.makeText(getContext(), getString(R.string.view_swiped_right, swipedElement), Toast.LENGTH_SHORT).show();
    }

    private void inputDialog(final String chatID, final String name, final String imageUrl, final String userID) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater inflater = this.getLayoutInflater();
        View mView = inflater.inflate(R.layout.match, null);
        builder.setView(mView);

        TextView textView = mView.findViewById(R.id.textLikeEachOther);
        textView.setText("You and "+name+" liked each other.");

        ImageView mine = mView.findViewById(R.id.pic1);
        Picasso.get().load(myInfo.getProfilePic()).into(mine);

        ImageView other = mView.findViewById(R.id.pic2);
        Picasso.get().load(imageUrl).into(other);

        final AlertDialog dialog = builder.create();
        dialog.show();

        Button sendMsg = mView.findViewById(R.id.sendMsgButt);
        sendMsg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Intent intent = new Intent(getActivity(), Chat.class);
                intent.putExtra("name", name);
                intent.putExtra("image", imageUrl);
                intent.putExtra("chatid", chatID);
                intent.putExtra("chatwith", userID);
                dialog.dismiss();
                startActivity(intent);
            }
        });

        Button keepSwiping = mView.findViewById(R.id.keepSwipeButt);
        keepSwiping.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });
    }


    @Override
    public void onViewSwipedToLeft(int position) {
        String swipedElement = mAdapter.getItem(position).getId();
        db.child("logs").child(mAuth.getUid()).child(mAdapter.getItem(position).getId()).setValue("nope");
        Toast.makeText(getContext(), getString(R.string.view_swiped_left, swipedElement), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStackEmpty() {
        Toast.makeText(getContext(), R.string.stack_empty, Toast.LENGTH_SHORT).show();
    }

    private void sendNotification(final String chatwith, final String uid, final String msg) {
        db.child("Tokens").child(chatwith).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.d("zxcv", dataSnapshot.child("token").getValue()+"");
                final Token token = new Token(dataSnapshot.child("token").getValue()+"");
                Data data =  new Data(mAuth.getUid(), R.mipmap.ic_launcher, "Chat now with "+myInfo.getFirstName(), "You have a new match!", chatwith);
                Sender sender = new Sender(data, token.getToken());
                apiService.sendNotification(sender)
                        .enqueue(new Callback<MyResponse>() {
                            @Override
                            public void onResponse(Call<MyResponse> call, Response<MyResponse> response) {
                                if(response.code()==200){
                                    if(response.body().success!=1){

                                    }
                                }
                            }

                            @Override
                            public void onFailure(Call<MyResponse> call, Throwable t) {

                            }
                        });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
