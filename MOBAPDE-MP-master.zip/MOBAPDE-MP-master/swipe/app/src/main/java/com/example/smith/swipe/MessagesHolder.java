package com.example.smith.swipe;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

// This class serves as the container class that the view rests on. All the manipulation and
// interaction functions of the view is stored here.
public class MessagesHolder extends RecyclerView.ViewHolder{
    private CircularImageView image;
    private TextView name;
    private TextView message;
    private String urli;
    private Context context;
    private String chatID;
    private String userID;

    DatabaseReference db;
    FirebaseAuth mAuth;


    public MessagesHolder(View view) {
        super(view);
        context = itemView.getContext();

        db = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        image = view.findViewById(R.id.image_icon);
        name = view.findViewById(R.id.name_field);
        message = view.findViewById(R.id.message_field);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("zxcv", chatID);
                final Intent intent = new Intent(context, Chat.class);
                intent.putExtra("name", name.getText().toString());
                intent.putExtra("image", urli);
                intent.putExtra("chatid", chatID);
                intent.putExtra("chatwith", userID);
                context.startActivity(intent);
            }
        });
    }

    public void init(final String chatID, String userID){
        this.userID = userID;
        this.chatID = chatID;
        db.child("basic").child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                name.setText(dataSnapshot.child("firstName").getValue()+"");
                urli = dataSnapshot.child("profilePic").getValue()+"";
                Picasso.get().load(urli).into(image);
                db.child("matches").child(mAuth.getUid()).child(chatID).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        try {
                            setMessage(dataSnapshot.child("lastMessageID").getValue().toString().replace("\n", " "));
                        } catch (Exception e){}
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public void setMessage(String newMsg){
        message.setText(newMsg);
    }
}
