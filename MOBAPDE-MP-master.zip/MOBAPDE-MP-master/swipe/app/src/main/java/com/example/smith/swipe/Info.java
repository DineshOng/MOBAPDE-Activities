package com.example.smith.swipe;

import java.util.Calendar;

public class Info {
    private String id, email;
    private String firstName, lastName;
    private String aboutMe, gender, pastSchool, pastWork, courseCode, bday, profilePic;
    private String idNum, intro;
    //private int month, day, year;
    private Anthem anthem;

    public Info() {

    }

    public Info(String profilePic, String firstName) {
        this.profilePic = profilePic;
        this.firstName = firstName;
    }

    public Info(String id, String email, String firstName, String lastName, String aboutMe, String gender, String pastSchool, String pastWork, String courseCode, String bday, String profilePic, String idNum, String intro, Anthem anthem) {
        this.id = id;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.aboutMe = aboutMe;
        this.gender = gender;
        this.pastSchool = pastSchool;
        this.pastWork = pastWork;
        this.courseCode = courseCode;
        this.bday = bday;
        this.profilePic = profilePic;
        this.idNum = idNum;
        this.intro = intro;
        this.anthem = anthem;
    }

    public Info(String id, String email, String firstName, String lastName, String aboutMe, String gender, String pastSchool, String pastWork, String courseCode, String bday, String profilePic, String idNum, Anthem anthem) {
        this.id = id;
        this.email = email;
        this.firstName = firstName;
        this.lastName = lastName;
        this.aboutMe = aboutMe;
        this.gender = gender;
        this.pastSchool = pastSchool;
        this.pastWork = pastWork;
        this.courseCode = courseCode;
        this.bday = bday;
        this.profilePic = profilePic;
        this.idNum = idNum;
        this.anthem = anthem;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public static String getAge(String b){
        String temp[] = b.split("/");
        Calendar dob = Calendar.getInstance();
        Calendar today = Calendar.getInstance();

        dob.set(Integer.valueOf(temp[2]), Integer.valueOf(temp[0]), Integer.valueOf(temp[1]));

        int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);

        if (today.get(Calendar.DAY_OF_YEAR) < dob.get(Calendar.DAY_OF_YEAR)){
            age--;
        }

        Integer ageInt = new Integer(age);
        String ageS = ageInt.toString();

        return ageS;
    }

    public String getAge() {
        return getAge(bday);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getPastSchool() {
        return pastSchool;
    }

    public void setPastSchool(String pastSchool) {
        this.pastSchool = pastSchool;
    }

    public String getPastWork() {
        return pastWork;
    }

    public void setPastWork(String pastWork) {
        this.pastWork = pastWork;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public String getBday() {
        return bday;
    }

    public void setBday(String bday) {
        this.bday = bday;
    }

    public String getProfilePic() {
        return profilePic;
    }

    public void setProfilePic(String profilePic) {
        this.profilePic = profilePic;
    }

    public String getIdNum() {
        return idNum;
    }

    public void setIdNum(String idNum) {
        this.idNum = idNum;
    }

    public Anthem getAnthem() {
        return anthem;
    }

    public void setAnthem(Anthem anthem) {
        this.anthem = anthem;
    }
}