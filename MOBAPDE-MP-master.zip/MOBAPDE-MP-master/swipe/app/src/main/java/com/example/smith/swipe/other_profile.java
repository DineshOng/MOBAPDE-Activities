package com.example.smith.swipe;

import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class other_profile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_profile);

        getSupportActionBar().hide();

        FloatingActionButton close = findViewById(R.id.closeFab);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        final ImageView imageView = findViewById(R.id.matches_icon);
        final TextView name = findViewById(R.id.name);
        final TextView age = findViewById(R.id.age);
        final ImageView gender = findViewById(R.id.gender);
        final TextView major = findViewById(R.id.major);

        final View introborder = findViewById(R.id.introborder);
        final TextView intro = findViewById(R.id.intro);

        final View infoborder = findViewById(R.id.infoborder);
        final TextView info = findViewById(R.id.info);

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        DatabaseReference db = FirebaseDatabase.getInstance().getReference();

        db.child("users").child(getIntent().getStringExtra("id")).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Info i = dataSnapshot.getValue(Info.class);

                Picasso.get().load(i.getProfilePic()).into(imageView);

                name.setText(i.getFirstName());

                if(i.getGender().equals("Male")){
                    gender.setImageResource(R.drawable.male2);
                } else {
                    gender.setImageResource(R.drawable.female2);
                }

                age.setText(i.getAge());

                if(i.getCourseCode()==null || i.getCourseCode().equals("")){
                    major.setVisibility(View.GONE);
                }else{
                    major.setText(i.getCourseCode());
                    major.setVisibility(View.VISIBLE);
                }

                if(i.getIntro()==null || i.getIntro().equals("")){
                    intro.setVisibility(View.GONE);
                    introborder.setVisibility(View.GONE);
                }else{
                    intro.setText(i.getIntro());
                    intro.setVisibility(View.VISIBLE);
                    introborder.setVisibility(View.VISIBLE);
                }

                if(i.getAboutMe()==null || i.getAboutMe().equals("")){
                    info.setVisibility(View.GONE);
                    infoborder.setVisibility(View.GONE);
                }else{
                    info.setText(i.getAboutMe());
                    info.setVisibility(View.VISIBLE);
                    infoborder.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
