package com.example.smith.swipe;

public class MyResponse {
    public int success;
}
