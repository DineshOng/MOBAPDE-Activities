package com.example.smith.swipe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import java.security.spec.ECField;

public class SelectGender extends AppCompatActivity {
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    Button cont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_gender);

        getSupportActionBar().hide();

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
                mAuth.signOut();
                startActivity(new Intent(SelectGender.this, Login.class));
            }
        });


        cont = findViewById(R.id.cont);
        cont.setEnabled(false);
        cont.setVisibility(View.INVISIBLE);
        sharedpreferences = getSharedPreferences(FirebaseAuth.getInstance().getCurrentUser().getUid(), Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();
        mAuth = FirebaseAuth.getInstance();
        String n[] = {};
        if(mAuth.getCurrentUser().getEmail().contains("dlsu"))
            n= mAuth.getCurrentUser().getEmail().split("@"); //nixon_ong dlsu.edu.ph

        String[] n1; //nixon ong
        String name = "";
        try {
            n1 = n[0].split("_");
            try{
                name = n1[2].substring(0, 1).toUpperCase() + n1[2].substring(1);
                cont.setText(name);
            } catch (Exception e){
                try {
                    name = n1[1].substring(0, 1).toUpperCase() + n1[1].substring(1);
                    cont.setText(name);
                } catch (Exception ee){

                }
            }
            editor.putString("lastName", name);
            name = n1[0].substring(0, 1).toUpperCase() + n1[0].substring(1);
            editor.putString("firstName", name);

        }catch (Exception e){
            name = mAuth.getCurrentUser().getDisplayName();
            editor.putString("firstName", name);
        }

        //String gender = sharedpreferences.getString("gender", "");
        /*if(gender.equals("Male")){
            male.setChecked(true);
        } else if (gender.equals("Female")){
            female.setChecked(true);
        }*/

        /*radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                switch (checkedId){
                    case R.id.male:
                        editor.putString("gender", "Male");
                        editor.apply();
                        break;
                    case R.id.female:
                        editor.putString("gender", "Female");
                        editor.apply();
                        break;
                }
            }
        });*/

        final ImageView female = findViewById(R.id.imgFemale);
        final ImageView male = findViewById(R.id.imgMale);

        final ImageView femalebox = findViewById(R.id.femalebox);
        final ImageView malebox = findViewById(R.id.malebox);

        femalebox.setVisibility(View.INVISIBLE);
        malebox.setVisibility(View.INVISIBLE);

        female.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                male.setImageResource(R.drawable.male2);
                editor.putString("gender", "Female");
                editor.apply();
                cont.setEnabled(true);
                cont.setVisibility(View.VISIBLE);
                femalebox.setVisibility(View.VISIBLE);
                malebox.setVisibility(View.INVISIBLE);
            }
        });


        male.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                female.setImageResource(R.drawable.female2);
                editor.putString("gender", "Male");
                editor.apply();
                cont.setEnabled(true);
                cont.setVisibility(View.VISIBLE);
                malebox.setVisibility(View.VISIBLE);
                femalebox.setVisibility(View.INVISIBLE);
            }
        });

        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SelectGender.this, SelectBday.class));
            }
        });
    }
}
