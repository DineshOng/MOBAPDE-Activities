package com.example.smith.swipe;

public class Anthem {
    private String artistName;
    private String trackName;
    private String previewURL;
    private String artworkUrl100;

    public Anthem(){

    }

    public Anthem(String artistName, String trackName, String previewURL, String artworkUrl100) {
        this.artistName = artistName;
        this.trackName = trackName;
        this.previewURL = previewURL;
        this.artworkUrl100 = artworkUrl100;
    }

    public String getArtistName() {
        return artistName;
    }

    public void setArtistName(String artistName) {
        this.artistName = artistName;
    }

    public String getTrackName() {
        return trackName;
    }

    public void setTrackName(String trackName) {
        this.trackName = trackName;
    }

    public String getPreviewURL() {
        return previewURL;
    }

    public void setPreviewURL(String previewURL) {
        this.previewURL = previewURL;
    }

    public String getArtworkUrl100() {
        return artworkUrl100;
    }

    public void setArtworkUrl100(String artworkUrl100) {
        this.artworkUrl100 = artworkUrl100;
    }
}
