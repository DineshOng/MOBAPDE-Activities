package com.example.smith.swipe;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageButton;

import com.google.firebase.auth.FirebaseAuth;

import java.util.Calendar;
import java.util.Date;

public class SelectBday extends AppCompatActivity {
    private DatePickerDialog.OnDateSetListener mDateSetListener;
    private Button b;
    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private int year, month, day;
    Button cont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_bday);

        sharedpreferences = getSharedPreferences(FirebaseAuth.getInstance().getCurrentUser().getUid(), Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();

        getSupportActionBar().hide();

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        /*b = findViewById(R.id.button3);
        //if(!sharedpreferences.getString("bday", "").equals("")) {
            b.setText(sharedpreferences.getString("bday", ""));
            editor.putString("bday", b.getText().toString());
        //}*/

        DatePicker dp = findViewById(R.id.datePicker);

        Calendar cal = Calendar.getInstance();
        year = cal.get(Calendar.YEAR);
        month = cal.get(Calendar.MONTH);
        day = cal.get(Calendar.DAY_OF_MONTH);

        //dp.init(sharedpreferences.getInt("year", year), sharedpreferences.getInt("month", month), sharedpreferences.getInt("day", day), null);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dp.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
                @Override
                public void onDateChanged(DatePicker view, int yearX, int monthX, int dayX) {
                    cont.setEnabled(true);
                    cont.setVisibility(View.VISIBLE);
                    year = yearX;
                    month = monthX;
                    day = dayX;
                }
            });
        }

        dp.setMinDate((long) (System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 365.25 * 28)));

        dp.setMaxDate((long) (System.currentTimeMillis() - (1000 * 60 * 60 * 24 * 365.25 * 13)));


        cont = findViewById(R.id.proButtBday);
        cont.setEnabled(false);
        cont.setVisibility(View.INVISIBLE);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editor.putString("bday", (month+1)+"/"+day+"/"+year);
                editor.apply();
                startActivity(new Intent(SelectBday.this, SelectProfilePic.class));
            }
        });

        /*mDateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                month = month + 1;
                Log.d("TAG", "onDateSet: mm/dd/yyy: " + month + "/" + day + "/" + year);

                String date = month + "/" + day + "/" + year;
                b.setText(date);
                editor.putString("bday", b.getText().toString());
                editor.apply();
            }
        };*/
    }
}
