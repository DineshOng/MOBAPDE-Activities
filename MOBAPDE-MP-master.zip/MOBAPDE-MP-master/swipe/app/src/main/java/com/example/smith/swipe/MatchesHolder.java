package com.example.smith.swipe;

import android.content.Context;
import android.content.Intent;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.squareup.picasso.Picasso;

// This class serves as the container class that the view rests on. All the manipulation and
// interaction functions of the view is stored here.
public class MatchesHolder extends RecyclerView.ViewHolder {
    private CircularImageView image;
    private TextView name;
    private String urli;
    private String chatID;
    private String userID;
    private Context context;
    DatabaseReference db;
    FirebaseAuth mAuth;

    public MatchesHolder(View view) {
        super(view);
        context = itemView.getContext();

        db = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();

        image = view.findViewById(R.id.matches_image_icon);
        name = view.findViewById(R.id.matches_name_field);

        //TODO if no message show "You matched with ____, Let's get things started." and profile Pic
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("zxcv", chatID);
                final Intent intent = new Intent(context, Chat.class);
                intent.putExtra("name", name.getText().toString());
                intent.putExtra("image", urli);
                intent.putExtra("chatid", chatID);
                intent.putExtra("chatwith", userID);
                context.startActivity(intent);
            }
        });
    }

    public void init(String chatID, String userID){
        this.userID = userID;
        this.chatID = chatID;
        db.child("basic").child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                name.setText(dataSnapshot.child("firstName").getValue()+"");
                urli = dataSnapshot.child("profilePic").getValue()+"";
                Picasso.get().load(urli).into(image);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
