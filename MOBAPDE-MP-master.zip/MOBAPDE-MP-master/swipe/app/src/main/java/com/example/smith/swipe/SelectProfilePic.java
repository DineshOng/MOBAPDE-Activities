package com.example.smith.swipe;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;

import com.google.android.gms.tasks.OnCanceledListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Random;

public class SelectProfilePic extends AppCompatActivity {
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthListener;

    private Button cont;
    private ImageView profilePic;
    private DatabaseReference db;
    private FirebaseStorage firebaseStorage;
    private static int PICK_IMAGE = 123;
    Uri imagePath;
    private StorageReference storageReference;
    private StorageReference myStorageRef;
    private String randString;
    private DatabaseReference myRef;

    SharedPreferences sharedpreferences;
    SharedPreferences.Editor editor;
    private ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_profile_pic);

        getSupportActionBar().hide();

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance().getReference();
        myRef = db.child("users").child(mAuth.getCurrentUser().getUid());
        firebaseStorage = FirebaseStorage.getInstance();

        storageReference = firebaseStorage.getReference();
        myStorageRef = storageReference.child(mAuth.getUid());

        sharedpreferences = getSharedPreferences(FirebaseAuth.getInstance().getCurrentUser().getUid(), Context.MODE_PRIVATE);
        editor = sharedpreferences.edit();

        profilePic = findViewById(R.id.profilePic);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);

        profilePic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select image"), PICK_IMAGE);
            }
        });

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });

        cont = findViewById(R.id.cont);
        cont.setVisibility(View.INVISIBLE);
        cont.setEnabled(false);
        cont.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                randString = generateRandString();
                UploadTask uploadTask = myStorageRef.child(randString).putFile(imagePath);
                uploadTask.addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        //myRef.child("imagge").setValue(myStorageRef.getDownloadUrl()+"");
                        storageReference.child(mAuth.getUid()).child(randString).getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                            @Override
                            public void onSuccess(Uri uri) {
                                db.child("basic").child(mAuth.getUid()).child("profilePic").setValue(uri+"");
                                db.child("basic").child(mAuth.getUid()).child("firstName").setValue(sharedpreferences.getString("firstName", ""));
                                myRef.child("profilePic").setValue(uri+"");
                                myRef.child("firstName").setValue(sharedpreferences.getString("firstName", ""));
                                db.child("basic").child(mAuth.getUid()).child("gender").setValue(sharedpreferences.getString("gender", ""));
                                myRef.child("gender").setValue(sharedpreferences.getString("gender", ""));
                                db.child("basic").child(mAuth.getUid()).child("bday").setValue(sharedpreferences.getString("bday", ""));
                                myRef.child("bday").setValue(sharedpreferences.getString("bday", ""));
                                db.child("userIDs").child(mAuth.getUid()).setValue(1);
                                db.child("ageGroup").child(Info.getAge(sharedpreferences.getString("bday", ""))).child(mAuth.getUid()).setValue(1);
                                String g = sharedpreferences.getString("gender", "");
                                if(g.equals("Male")) {
                                    db.child("genders").child("male").child(mAuth.getUid()).setValue(1);
                                } else if(g.equals("Female")) {
                                    db.child("genders").child("female").child(mAuth.getUid()).setValue(1);
                                }
                                progressBar.setVisibility(View.INVISIBLE);
                                startActivity(new Intent(SelectProfilePic.this, SelectAllSet.class));
                            }
                        });
                        //Toast.makeText(Main2Activity.this, myStorageRef.getDownloadUrl()+"", Toast.LENGTH_LONG).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = 100.0 * (taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        System.out.println("Upload is " + progress + "% done");
                        int currentprogress = (int) progress;
                        progressBar.setVisibility(View.VISIBLE);
                        progressBar.setProgress(currentprogress);
                    }
                }).addOnCanceledListener(new OnCanceledListener() {
                    @Override
                    public void onCanceled() {

                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == PICK_IMAGE && resultCode == RESULT_OK && data.getData() != null){
            imagePath = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imagePath);
                profilePic.setImageBitmap(bitmap);
                //myStorageRef = storageReference.child(mAuth.getUid()).child(generatedString);
                editor.putString("image", imagePath.toString());
                editor.apply();
                cont.setVisibility(View.VISIBLE);
                cont.setEnabled(true);
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    public String generateRandString() {
        byte[] array = new byte[7]; // length is bounded by 7
        new Random().nextBytes(array);
        return new String(array, Charset.forName("UTF-8"));
    }
}
