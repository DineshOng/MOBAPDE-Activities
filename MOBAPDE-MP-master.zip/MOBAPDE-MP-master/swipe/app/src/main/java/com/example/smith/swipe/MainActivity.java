package com.example.smith.swipe;

import android.app.ActionBar;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(this);

        Button b = findViewById(R.id.addMessage);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity.this, Login.class));
            }
        });

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        getWindow().setStatusBarColor(Color.TRANSPARENT);

        /*ConstraintLayout.LayoutParams newLayoutParams = (ConstraintLayout.LayoutParams) b.getLayoutParams();
        newLayoutParams.topMargin = getStatusBarHeight();
        newLayoutParams.leftMargin = 1;
        newLayoutParams.rightMargin = 1;
        b.setLayoutParams(newLayoutParams);*/

        FrameLayout f = findViewById(R.id.fragment_container);

        /*newLayoutParams = (ConstraintLayout.LayoutParams) f.getLayoutParams();
        newLayoutParams.topMargin = getStatusBarHeight();
        newLayoutParams.leftMargin = 1;
        newLayoutParams.rightMargin = 1;
        f.setLayoutParams(newLayoutParams);*/

        /*if (getIntent().getStringExtra("act").equals("profile"))
            loadFragment(new ProfileFragment());
        else if (getIntent().getStringExtra("act").equals("messages"))
            loadFragment(new MessageFragment());*/

        /*getSupportActionBar().setElevation(0);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(Color.WHITE)); // set your desired color


        tv = new TextView(getApplicationContext());

        // Create a LayoutParams for TextView
        LayoutParams lp = new RelativeLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, // Width of TextView
                LayoutParams.WRAP_CONTENT); // Height of TextView
        tv.setLayoutParams(lp);
        tv.setText(getSupportActionBar().getTitle());
        tv.setTextColor(Color.BLACK);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP,30);
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(tv);*/

        getSupportActionBar().hide();

        loadFragment(new CardsFragment());
        navigation.setSelectedItemId(R.id.nav_cards);
    }

    private boolean loadFragment(Fragment fragment) {
        if(fragment != null){
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragment_container, fragment)
                    .commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;
        switch (item.getItemId()){
            case R.id.nav_profile:
                fragment = new ProfileFragment();
                //getActionBar().set
                //getSupportActionBar().setTitle("Profile");
                //tv.setText("Profile");
                //getSupportActionBar().show();
                break;
            case R.id.nav_cards:
                fragment = new CardsFragment();
                //startActivity(new Intent(MainActivity.this, Cards.class));
                //getSupportActionBar().setTitle("Discover");
                //tv.setText("Discover");
                //getSupportActionBar().hide();
                break;
            case R.id.nav_message:
                fragment = new MessagesFragment();
                //getSupportActionBar().setTitle("Messages");
                //tv.setText("Messages");
                break;
        }
        return loadFragment(fragment);
    }

    public int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }
}
