package com.example.smith.swipe;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;

//(1) The ContactAdapter is a child of RecyclerView.Adapter and uses the holder ContactHolder.
//    This means the adapter manages entries of ContactHolder
public class MatchesAdapter extends RecyclerView.Adapter<MatchesHolder> {

    //(2) The constructor and ArrayList are used to keep track of the information displayed. Though
    //    the RecyclerView.Adapter functions manage the views in the holders, the information in
    //    the views are kept separately and should be managed by the adapter class itself.
    private ArrayList<ContactModel> contactList;
    private Activity activity;

    public String getRandom(){
        Random r = new Random();
        return "09"+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+""+r.nextInt(9)+"";
    }

    public MatchesAdapter(Activity activity){
        contactList = new ArrayList<ContactModel>();
        this.activity = activity;
        //(3) The hard coded entries as shown here illustrate how information can be initially
        //    populated onto a list. It is also possible to pass information onto the constructor
        //    which will be used to populate the list.
        //contactList.add(new ContactModel(getRandom(), "https://pbs.twimg.com/profile_images/1060289464101044224/3qLGI7LF_400x400.jpg", "Erni", getRandom()));
        //contactList.add(new ContactModel(getRandom(), "https://pbs.twimg.com/profile_images/1060289464101044224/3qLGI7LF_400x400.jpg", "Nixon", getRandom()));
        //contactList.add(new ContactModel(getRandom(), "https://pbs.twimg.com/profile_images/1060289464101044224/3qLGI7LF_400x400.jpg", "Nyles", getRandom()));
    }

    //(4) The onCreateViewHolder function is used to create the views to be used. This function
    //    expects a holder with a view to be returned. The information in the holder will be
    //    overwritten in another function.

    @Override
    public MatchesHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //(5) An inflater is again used to populate the view. This information can be directly
        //    taken from a layout.
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.matches_column, parent, false);

        //(6) The view created must be given to a holder. The holder will serve as the in-between
        //    system that interacts with the view.
        MatchesHolder holder = new MatchesHolder(view);
        return holder;
    }

    //(7) The onBindViewHolder function is called to replace the information of the view on a
    //    specific position. This is why the position parameter will dictate what information
    //    should be displayed on the specific view.
    @Override
    public void onBindViewHolder(MatchesHolder holder, final int position) {
        //holder.setIcon(contactList.get(position).getImage());
        //holder.setName(contactList.get(position).getName(), contactList.get(position).getChatID(), contactList.get(position).getUserID());
        holder.init(contactList.get(position).getChatID(), contactList.get(position).getUserID());
    }

    //(8) As the list of information grows, the adapter's parent functions must be notified of the
    //    change of size in the list of elements. Thus it needs the getItemCount function to
    //    indicate the current size of the list of elements.
    @Override
    public int getItemCount() {
        return contactList.size();
    }

    //(9) Information can be added later on but the notifyItemInserted function must be called to
    //    tell the system a new piece of information is added.
    public void addItem(String chatID, String id){
        contactList.add(new ContactModel(chatID, null, null, null, id));
        notifyItemInserted(contactList.size()-1);
    }
}
