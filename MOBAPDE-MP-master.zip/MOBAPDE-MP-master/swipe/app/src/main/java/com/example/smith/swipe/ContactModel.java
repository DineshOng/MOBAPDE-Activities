package com.example.smith.swipe;

import java.io.Serializable;

// This class is a bean class that contains a single contact row's information. The getters and
// setters were made using the Refactor -> Encapsulate fields feature of Android Studio
public class ContactModel {
    private String chatID;
    private String image;
    private String name;
    private String message;
    private String userID;

    public ContactModel(String chatID, String image, String name, String message, String userID) {
        this.chatID = chatID;
        this.image = image;
        this.name = name;
        this.message = message;
        this.userID = userID;
    }

    public String getChatID() {
        return chatID;
    }

    public void setChatID(String chatID) {
        this.chatID = chatID;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
