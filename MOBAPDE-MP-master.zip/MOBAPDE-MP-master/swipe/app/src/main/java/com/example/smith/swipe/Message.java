package com.example.smith.swipe;

public class Message {
    private String text;
    private String name;
    private String image;
    private boolean belongsToCurrentUser;

    public Message(String text, String name, String image, boolean belongsToCurrentUser) {
        this.text = text;
        this.name = name;
        this.image = image;
        this.belongsToCurrentUser = belongsToCurrentUser;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public boolean isBelongsToCurrentUser() {
        return belongsToCurrentUser;
    }

    public void setBelongsToCurrentUser(boolean belongsToCurrentUser) {
        this.belongsToCurrentUser = belongsToCurrentUser;
    }
}
