package com.example.g301.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private int imageSet[];
    ImageView img1, img2, img3;
    private int attempts;
    private int curr1, curr2, curr3;
    private int c1, c2, c3;
    private TextView att;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img1 = findViewById(R.id.image1);
        img2 = findViewById(R.id.image2);
        img3 = findViewById(R.id.image3);

        att = findViewById(R.id.att);

        attempts = 0;
        curr1 = 0;
        curr2 = 0;
        curr3 = 0;

        imageSet = new int[]{
                R.drawable.yinyang,R.drawable.bat,
                R.drawable.ironcross,R.drawable.hearts,
                R.drawable.staryu,R.drawable.triforce};

        Button u1 = findViewById(R.id.u1);
        Button u2 = findViewById(R.id.u2);
        Button u3 = findViewById(R.id.u3);

        Button d1 = findViewById(R.id.d1);
        Button d2 = findViewById(R.id.d2);
        Button d3 = findViewById(R.id.d3);

        Button unlock = findViewById(R.id.unlock);

        unlock.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(curr1==c1 && curr2==c2 && curr3==c3){
                    Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                    MainActivity.this.startActivity(intent);
                } else{
                    attempts++;
                    att.setText("Attempts: "+attempts);
                }
            }
        });

        img1.setImageResource(imageSet[0]);
        img2.setImageResource(imageSet[0]);
        img3.setImageResource(imageSet[0]);

        u1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int temp = (curr1+1)%6;
                img1.setImageResource(imageSet[temp]);
                curr1 = temp;
            }
        });

        u2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int temp = (curr2+1)%6;
                img2.setImageResource(imageSet[temp]);
                curr2 = temp;
            }
        });

        u3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int temp = (curr3+1)%6;
                img3.setImageResource(imageSet[temp]);
                curr3 = temp;
            }
        });

        d1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(curr1>=1) {
                    int temp = (curr1-1) % 6;
                    img1.setImageResource(imageSet[temp]);
                    curr1 = temp;
                } else
                    img1.setImageResource(imageSet[curr1]);
            }
        });

        d2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(curr2>=1) {
                    int temp = (curr2-1) % 6;
                    img2.setImageResource(imageSet[temp]);
                    curr2 = temp;
                } else
                    img2.setImageResource(imageSet[curr2]);
            }
        });

        d3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if(curr3>=1) {
                    int temp = (curr3-1) % 6;
                    img3.setImageResource(imageSet[temp]);
                    curr3 = temp;
                } else
                    img3.setImageResource(imageSet[curr3]);
            }
        });
    }

    @Override
    protected void onPause(){
        super.onPause();

        SharedPreferences.Editor preferenceEditor = getSharedPreferences("sharedPref", MODE_PRIVATE).edit();
        preferenceEditor.putInt("att", attempts);
        preferenceEditor.putInt("c1", c1);
        preferenceEditor.putInt("c2", c2);
        preferenceEditor.putInt("c3", c3);
        preferenceEditor.commit();
    }

    @Override
    protected void onResume(){
        super.onResume();

        SharedPreferences preferencesSettings = getSharedPreferences("sharedPref", MODE_PRIVATE);
        attempts = preferencesSettings.getInt("att", 0);
        att.setText("Attempts :"+attempts);
        c1 = preferencesSettings.getInt("c1", 0);
        c2 = preferencesSettings.getInt("c2", 0);
        c3 = preferencesSettings.getInt("c3", 0);
    }
}
