package ph.edu.dlsu.ccs.a13_recyclerview;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

// This class serves as the container class that the view rests on. All the manipulation and
// interaction functions of the view is stored here.
public class ContactHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    private ImageView image;
    private TextView name;
    private Button button;
    private String num;

    public ContactHolder(View view) {
        super(view);

        image = view.findViewById(R.id.imageView);
        name = view.findViewById(R.id.textView);
        button = view.findViewById(R.id.button2);

        button.setOnClickListener(this);
    }

    public void setIcon(int newImg){
        image.setImageResource(newImg);
    }

    public void setName(String newName){
        name.setText(newName);
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == button.getId()) {
            //Toast.makeText(v.getContext(), "ITEM PRESSED = " + String.valueOf(getAdapterPosition()) + " " + num , Toast.LENGTH_SHORT).show();
            Context context = v.getContext();
            Intent intent = new Intent(context, Main2Activity.class);
            intent.putExtra("img", name.getText().toString());
            context.startActivity(intent);
        } else {
            //Toast.makeText(v.getContext(), "ROW PRESSED = " + String.valueOf(getAdapterPosition()) + " " + num, Toast.LENGTH_SHORT).show();
        }

        //listenerRef.get().onPositionClicked(getAdapterPosition());
    }
}
