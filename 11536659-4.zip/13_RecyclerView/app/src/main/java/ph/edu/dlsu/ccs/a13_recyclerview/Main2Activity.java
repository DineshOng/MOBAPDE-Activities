package ph.edu.dlsu.ccs.a13_recyclerview;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        String imgx = getIntent().getStringExtra("img");
        ImageView imageView = findViewById(R.id.imageView2);
        String draw = "drawable/"+"img"+imgx.toString();
        TextView tv = findViewById(R.id.textView2);
        tv.setText(imgx.toString());
        imageView.setImageResource(getResources().getIdentifier(draw, "drawable", getPackageName()));
    }
}
