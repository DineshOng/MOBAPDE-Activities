package ph.edu.dlsu.ccs.a13_recyclerview;

import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerArea;
    private ContactAdapter adapter;
    private RecyclerView.LayoutManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button b = findViewById(R.id.button);
        b.setVisibility(View.INVISIBLE);

        //(1) The RecyclerView is where the recycling will be done. In this case, this has already
        //    been declared in the activity_main.xml
        recyclerArea = findViewById(R.id.recycler_area);

        //(2) The LinearLayoutManager is in-charge of the layout of the RecyclerView
        manager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        recyclerArea.setLayoutManager(manager);

        //(3) The RecyclerView.Adapter manages the internal content of the RecyclerView
        adapter = new ContactAdapter();
        for(int i=1; i<=20; i++){
            String draw = "drawable/"+"img"+i;
            adapter.addItem(getResources().getIdentifier(draw, "drawable", getPackageName()), i+"");
        }
        recyclerArea.setAdapter(adapter);
    }
}
