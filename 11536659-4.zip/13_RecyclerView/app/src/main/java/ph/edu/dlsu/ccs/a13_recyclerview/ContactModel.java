package ph.edu.dlsu.ccs.a13_recyclerview;

// This class is a bean class that contains a single contact row's information. The getters and
// setters were made using the Refactor -> Encapsulate fields feature of Android Studio
public class ContactModel {
    private int image;
    private String name;
    private String num;

    public ContactModel(int iV, String nV, String noV){
        image = iV;
        name = nV;
        num = noV;
    }
    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }
}
