package ph.edu.dlsu.ccs.a13_recyclerview;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Random;

//(1) The ContactAdapter is a child of RecyclerView.Adapter and uses the holder ContactHolder.
//    This means the adapter manages entries of ContactHolder
public class ContactAdapter extends RecyclerView.Adapter<ContactHolder> {

    //(2) The constructor and ArrayList are used to keep track of the information displayed. Though
    //    the RecyclerView.Adapter functions manage the views in the holders, the information in
    //    the views are kept separately and should be managed by the adapter class itself.
    private ArrayList<ContactModel> contactList;

    public ContactAdapter(){
        contactList = new ArrayList<ContactModel>();
    }

    //(4) The onCreateViewHolder function is used to create the views to be used. This function
    //    expects a holder with a view to be returned. The information in the holder will be
    //    overwritten in another function.
    @Override
    public ContactHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //(5) An inflater is again used to populate the view. This information can be directly
        //    taken from a layout.
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.contact_row, parent, false);

        //(6) The view created must be given to a holder. The holder will serve as the in-between
        //    system that interacts with the view.
        ContactHolder holder = new ContactHolder(view);
        return holder;
    }

    //(7) The onBindViewHolder function is called to replace the information of the view on a
    //    specific position. This is why the position parameter will dictate what information
    //    should be displayed on the specific view.
    @Override
    public void onBindViewHolder(ContactHolder holder, final int position) {
        holder.setIcon(contactList.get(position).getImage());
        holder.setName(contactList.get(position).getName());
        holder.setNum(contactList.get(position).getNum());
    }

    //(8) As the list of information grows, the adapter's parent functions must be notified of the
    //    change of size in the list of elements. Thus it needs the getItemCount function to
    //    indicate the current size of the list of elements.
    @Override
    public int getItemCount() {
        return contactList.size();
    }

    //(9) Information can be added later on but the notifyItemInserted function must be called to
    //    tell the system a new piece of information is added.
    public void addItem(int img,String name){
        contactList.add(new ContactModel(img, name, ""));
        notifyItemInserted(contactList.size()-1);
    }
}
