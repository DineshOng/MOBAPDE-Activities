Lesson notes for project:
1. Bottom Navigations sometimes have issues on the rendering of the designer.
   A. Refresh the project and fix the styles.xml
      - add Base in the styles.xml
      - go to File -> Invalidate Caches / Restart
   B. If process A does not work, add the code snippet at the build.gradle(Module:app) file and
      synchronize the file. This will take some time.

   configurations.all {
       resolutionStrategy.eachDependency { DependencyResolveDetails details ->
           def requested = details.requested
           if (requested.group == "com.android.support") {
               if (!requested.name.startsWith("multidex")) {
                   details.useVersion "27.+"
               }
           }
       }
   }

   - https://stackoverflow.com/questions/51797374/failed-to-find-style-bottomnavigationstyle-in-current-theme
   - https://stackoverflow.com/questions/52017363/theme-error-how-to-fix
2. Bottom Navigation can be made in Android Studio as part of the project. By selecting the bottom
   navigation instead of blank project, one can make a project with it built in.
3. The Bottom Navigation is a form of Menu that is attached to the bottom of a screen but
   interacting with the bottom menu is not the same as the top menu. Instead of using a function on
   the Activity, a listener is attached to the bottom menu. The OnNavigationItemSelectedListener is
   used as the listener.
4. Typically the first item is selected by default which means the user is currently in the home
   page.
5. To display an image on the menu, there is an option found in the navigation menu for the image.
6. Refrain from adding more than 5 menu items for the bottom menu. The menu will no longer look
   good after that point.
7. If resizing the icons and checking for compatibility of sizes is an issue, use the
   new -> image asset and look at the dropdown. This feature is not only used for making launcher
   icons but can also be used for menu and tab icons.

Credits:
   All icons are taken from https://game-icons.net/
   Icons Goat and Pig are made by Skoll
   Icons Cow and Chicken are made by Delapouite

Self-Practise:
  As a practise, try to modify the project and add another animal named into the menu. Make sure
  that it also works and changes both the image and the text. It must have an icon that is attached
  to the menu. As a suggestion, a duck can be added.

  https://game-icons.net/delapouite/originals/duck.html
