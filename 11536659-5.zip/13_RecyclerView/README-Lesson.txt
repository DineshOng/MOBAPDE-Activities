Lesson notes for project:
1. The Recycler View is a result of the optimizations that Android has implemented. Though there is
   more processing power and Ram, the battery suffers when the code is not properly done. Thus to
   save on resources, the Recycler View recycles the views so that it does not create more than
   it needs to.
2. The Recycler View system needs 4 major components:
   * RecyclerView - serves as the area where the recycler view elements are placed
   * LayoutManager - manages the recycler view elements in the form of a layout
   * Adapter - In charge of replacing the content of old views so that it can be used as a new view
   * Holder - A wrapper that allows views to be processed by the Adapter
3. Look at MainActivity to see how the different components interact. Afterwards, look at the
   ContactAdapter class to see how the data is managed then finally look at the ContactHolder to
   see how the views and are wrapped.

Credits:
   All icons are taken from https://game-icons.net/
   Icons Goat and Pig are made by Skoll
   Icons Cow and Chicken are made by Delapouite

Self-Practise:
  As a practise, try to modify the project so that it uses Saved Preferences. This will save the
  last selected action of the user and will load the last action so that the icon on the page is
  different on start-up. Or alternatively, make it so that the old activity is opened when the
  notification is pressed.


