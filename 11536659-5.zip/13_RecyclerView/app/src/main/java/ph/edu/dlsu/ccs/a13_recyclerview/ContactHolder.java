package ph.edu.dlsu.ccs.a13_recyclerview;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

// This class serves as the container class that the view rests on. All the manipulation and
// interaction functions of the view is stored here.
public class ContactHolder extends RecyclerView.ViewHolder{

    private ImageView image;
    private TextView name;

    public ContactHolder(View view) {
        super(view);

        image = view.findViewById(R.id.imageView);
        name = view.findViewById(R.id.textView);
    }

    public void setIcon(int newImg){
        image.setImageResource(newImg);
    }

    public void setName(String newName){
        name.setText(newName);
    }
}
