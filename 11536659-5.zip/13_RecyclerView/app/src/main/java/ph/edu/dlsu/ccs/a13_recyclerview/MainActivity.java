package ph.edu.dlsu.ccs.a13_recyclerview;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerArea;
    private ContactAdapter adapter;
    private RecyclerView.LayoutManager manager;
    private int[] imageSet;
    private String[] names, bird, dino, donkey, horse, hound, parrot, serpent, squid;
    private Button send;
    private EditText input;
    private Random r;

    public static final String UI_UPDATE_TAG =
            "ph.edu.dlsu.ccs.a13_recyclerview.MainActivity.ActivityReceiver";
    private BroadcastReceiver receiver = new ph.edu.dlsu.ccs.a13_recyclerview.MainActivity.ActivityReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        IntentFilter filter = new IntentFilter();
        filter.addAction(UI_UPDATE_TAG);
        registerReceiver(receiver, filter);

        imageSet = new int[]{
                R.drawable.bird_twitter,R.drawable.dinosaur_rex,
                R.drawable.donkey,R.drawable.horse_head,
                R.drawable.hound,R.drawable.parrot_head,
                R.drawable.sea_serpent,R.drawable.squid,
                R.drawable.id_card};

        names = new String[] {"bird_twitter", "dinosaur_rex", "donkey", "horse_head", "hound", "parrot_head", "sea_serpent", "squid"};

        recyclerArea = findViewById(R.id.recycler_area);
        send = findViewById(R.id.send);
        input = findViewById(R.id.input);

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!input.getText().toString().equals("")) {
                    adapter.addItem(new ContactModel(imageSet[8], "Me", input.getText().toString()));
                    input.setText("");
                }
            }
        });

        manager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerArea.setLayoutManager(manager);
        r = new Random();
        ArrayList a = new ArrayList();
        adapter = new ContactAdapter();
        for(int i=0; i<5; i++){
            int x = r.nextInt(8);
            String y = r.nextInt(4)+"";
            while(a.contains(x))
                x = r.nextInt(8);
            a.add(x);
            ContactModel cm = new ContactModel(imageSet[x], names[x], y);
            adapter.addItem(cm);
            downloadedService(cm);
        }
        recyclerArea.setAdapter(adapter);
    }

    public void downloadedService(ContactModel x){
        Intent downloadIntent = new Intent(UI_UPDATE_TAG);
        downloadIntent.putExtra("lozol", x.getImage());
        //downloadIntent.putExtra(i+"", x);

        //(4) The next is a PendingIntent which is an intent but used for pending tasks. Note that
        //    for every new PendingIntent to be sent, one must update the request code.
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, downloadIntent, 0);

        int time = 0;

        if (x.getImage() == 0) {
            time = 2 * 1000;
        } else if (x.getImage() == 1) {
            time = 8 * 1000;
        } else if (x.getImage() == 2) {
            time = 4 * 1000;
        } else if (x.getImage() == 3) {
            time = 3 * 1000;
        }else if (x.getImage() == 4) {
            time = 1 * 1000;
        }else if (x.getImage() == 5) {
            time = 5 * 1000;
        }else if (x.getImage() == 6) {
            time = 7 * 1000;
        }else if (x.getImage() == 7) {
            time = 7 * 1000;
        }

        //(5) Finally the AlarmManager manages how the alarm will be sent. This Alarm will manage
        //    and schedule when the alarm is to be sent.
        AlarmManager manager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + time, pendingIntent);
    }

    public class ActivityReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            int abc = intent.getIntExtra("lozol", 0);
            ContactModel cm = new ContactModel(imageSet[r.nextInt(8)], names[r.nextInt(8)], r.nextInt()+"");
            adapter.addItem(cm);
            downloadedService(cm);
        }
    }

    private String getResourceFromString(MainActivity activity, String id) {
        String packagename = activity.getPackageName();
        int resId = activity.getResources().getIdentifier(id, "string", packagename);
        return activity.getString(resId);
    }

}
