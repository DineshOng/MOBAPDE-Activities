package ph.edu.dlsu.ccs.a13_recyclerview;

// This class is a bean class that contains a single contact row's information. The getters and
// setters were made using the Refactor -> Encapsulate fields feature of Android Studio
public class ContactModel {
    private int image;
    private String name;
    private String chat;

    public ContactModel(int iV, String nV, String cV){
        image = iV;
        name = cV;
        chat = nV;
    }
    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getChat() {
        return chat;
    }

    public void setChat(String chat) {
        this.chat = chat;
    }
}
