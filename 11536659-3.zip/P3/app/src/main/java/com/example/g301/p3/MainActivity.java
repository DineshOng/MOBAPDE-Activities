package com.example.g301.p3;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView tv;
    private boolean checker;
    private String msg;
    private int money;
    private Button button;
    private String farms[] = {"Chicken", "Beef", "Pork"};
    private ArrayList<String> myFarm;
    private int imageSet[];
    private int i;

    public static final String UI_UPDATE_TAG =
            "com.example.g301.p3.MainActivity.ActivityReceiver";
    private BroadcastReceiver receiver = new ActivityReceiver();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myFarm = new ArrayList<String>();
        money = 20;
        i = 0;
        imageSet = new int[]{
                R.drawable.chicken_sq,
                R.drawable.cow_sq,
                R.drawable.pig_sq };

        //scView = findViewById(R.id.scrollView);
        tv = findViewById(R.id.textView);
        tv.setText("Money: "+money);
        checker = true;

        //(2) The registration of ActivityReceiver is similar to how it is done in the previous
        //    code sample.
        IntentFilter filter = new IntentFilter();
        filter.addAction(UI_UPDATE_TAG);
        registerReceiver(receiver, filter);
    }

    public void onStart() {

        super.onStart();

        //downloadedService();

    }

    public void buyFarm(View view){
        //checker = false;
        if(money>=10) {

            LinearLayout parent = findViewById(R.id.farm_layout);

            //children of parent linearlayout

            LinearLayout layout2 = new LinearLayout(MainActivity.this);

            layout2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            layout2.setOrientation(LinearLayout.HORIZONTAL);

            parent.addView(layout2);

            TextView tv1 = new TextView(MainActivity.this);
            ImageView e = new ImageView(MainActivity.this);

            LinearLayout.LayoutParams parms = new LinearLayout.LayoutParams(32*3, 32*3);
            e.setLayoutParams(parms);

            Random rand = new Random();

            int x = rand.nextInt(3);

            if (farms[x].equals("Chicken")) {
                tv1.setText(farms[x] + " Farm");
                e.setImageResource(imageSet[0]);
            } else if (farms[x].equals("Beef")) {
                tv1.setText(farms[x] + " Farm");
                e.setImageResource(imageSet[1]);
            } else if (farms[x].equals("Pork")) {
                tv1.setText(farms[x] + " Farm");
                e.setImageResource(imageSet[2]);
            }

            layout2.addView(e);
            layout2.addView(tv1);


            myFarm.add(farms[x]);
            money -= 10;
            tv.setText("Money: "+money);
            downloadedService(farms[x]);
            i++;
            //Toast.makeText(getApplicationContext(), "Download Complete!", Toast.LENGTH_SHORT).show();
        }
    }

    public void downloadedService(String x){
        Intent downloadIntent = new Intent(UI_UPDATE_TAG);
        downloadIntent.putExtra(i+"", x);

        //(4) The next is a PendingIntent which is an intent but used for pending tasks. Note that
        //    for every new PendingIntent to be sent, one must update the request code.
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, downloadIntent, 0);

        int time = 0;

        if (x.equals("Chicken")) {
            time = 3 * 1000;
        } else if (x.equals("Beef")) {
            time = 7 * 1000;
        } else if (x.equals("Pork")) {
            time = 5 * 1000;
        }

        //(5) Finally the AlarmManager manages how the alarm will be sent. This Alarm will manage
        //    and schedule when the alarm is to be sent.
        AlarmManager manager = (AlarmManager)getSystemService(Context.ALARM_SERVICE);
        manager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + time, pendingIntent);
    }

    public class ActivityReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            int income = 0;
            Random rand = new Random();

            //String x = intent.getStringExtra(i+"");
            String x =  "Beef";

            //Log.d("TAG", intent.getStringExtra("farm"));

            if (x.equals("Chicken")) {
                income = rand.nextInt(2)+2;
            } else if (x.equals("Beef")) {
                income = rand.nextInt(2)+8;
            } else if (x.equals("Pork")) {
                income = rand.nextInt(2)+6;
            }
            money += income;
            tv.setText("Money: "+money);
            downloadedService(x);
        }
    }

}
