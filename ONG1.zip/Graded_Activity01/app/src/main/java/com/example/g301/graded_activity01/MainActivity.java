package com.example.g301.graded_activity01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView txt = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button opsbt = findViewById(R.id.btops);

        Button bt1 = findViewById(R.id.bt1);
        Button bt2 = findViewById(R.id.bt2);
        Button bt3 = findViewById(R.id.bt3);
        Button bt4 = findViewById(R.id.bt4);
        Button bt5 = findViewById(R.id.bt5);
        Button bt6 = findViewById(R.id.bt6);
        Button bt7 = findViewById(R.id.bt7);
        Button bt8 = findViewById(R.id.bt8);
        Button bt9 = findViewById(R.id.bt9);
        Button bt0 = findViewById(R.id.bt0);

        txt = findViewById(R.id.txtfield);
        txt.setEnabled(false);

        opsbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!txt.getText().equals("")) {
                    Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                    intent.putExtra("en", txt.getText().toString());
                    MainActivity.this.startActivity(intent);
                    MainActivity.this.finish();
                }
            }
        });

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="1";
                txt.setText(temp);
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="2";
                txt.setText(temp);
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="3";
                txt.setText(temp);
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="4";
                txt.setText(temp);
            }
        });

        bt5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="5";
                txt.setText(temp);
            }
        });

        bt6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="6";
                txt.setText(temp);
            }
        });

        bt7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="7";
                txt.setText(temp);
            }
        });

        bt8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="8";
                txt.setText(temp);
            }
        });

        bt9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="9";
                txt.setText(temp);
            }
        });

        bt0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp+="0";
                txt.setText(temp);
            }
        });
    }
}
