package com.example.g301.graded_activity01;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView txt = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        txt = findViewById(R.id.txt);

        String Item = getIntent().getExtras().getString("en");
        txt.setEnabled(false);
        txt.setText(Item.toString());

        Button bta = findViewById(R.id.bta);
        Button bts = findViewById(R.id.bts);
        Button btm = findViewById(R.id.btm);
        Button btd = findViewById(R.id.btd);
        Button bte = findViewById(R.id.bte);

        bta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp += "+";
                txt.setText(temp);
                getIntent().putExtra("en", txt.getText().toString());
                getIntent().setClass(getApplicationContext(), MainActivity.class);
                MainActivity2.this.startActivity(getIntent());
                MainActivity2.this.finish();
            }
        });

        bts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp += "-";
                txt.setText(temp);
                getIntent().putExtra("en", txt.getText().toString());
                getIntent().setClass(getApplicationContext(), MainActivity.class);
                MainActivity2.this.startActivity(getIntent());
                MainActivity2.this.finish();
            }
        });

        btm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp += "x";
                txt.setText(temp);
                getIntent().putExtra("en", txt.getText().toString());
                getIntent().setClass(getApplicationContext(), MainActivity.class);
                MainActivity2.this.startActivity(getIntent());
                MainActivity2.this.finish();
            }
        });

        btd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                temp += "/";
                txt.setText(temp);
                getIntent().putExtra("en", txt.getText().toString());
                getIntent().setClass(getApplicationContext(), MainActivity.class);
                MainActivity2.this.startActivity(getIntent());
                MainActivity2.this.finish();
            }
        });

        bte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String temp = txt.getText().toString();
                //temp+="+";
                //txt.setText(temp);
            }
        });
    }
}
