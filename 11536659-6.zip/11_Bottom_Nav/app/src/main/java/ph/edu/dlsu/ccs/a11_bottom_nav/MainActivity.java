package ph.edu.dlsu.ccs.a11_bottom_nav;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.BitmapFactory;
import android.inputmethodservice.Keyboard;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private ImageView imageArea;
    private BottomNavigationView navigation;
    private MenuInflater inflater;
    private int curr;
    private AlertDialog dialog;
    private EditText editText;
    View mView;

    private static final String CHANNEL_ID = "ph.edu.dlsu.a09a_notifications.NOTIFICATION";
    private int notificationID = 12;

    @SuppressLint("WrongConstant")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imageArea = findViewById(R.id.profile_pic);


        navigation = findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.nav_1:
                        imageArea.setImageResource(R.drawable.puzzle1_p);
                        curr = 1;
                        return true;
                    case R.id.nav_2:
                        imageArea.setImageResource(R.drawable.puzzle2_p);
                        curr = 2;
                        return true;
                    case R.id.nav_3:
                        imageArea.setImageResource(R.drawable.puzzle3_p);
                        curr = 3;
                        return true;
                    case R.id.nav_4:
                        inputDialog();
                        return true;
                }
                return false;
            }
        });

        navigation.setSelectedItemId(R.id.nav_1);
        Toast.makeText(getBaseContext(), R.string.intro, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        int orientation=newConfig.orientation;
        switch(orientation) {
            case Configuration.ORIENTATION_LANDSCAPE:
                navigation.setVisibility(View.INVISIBLE);
                navigation.setSelectedItemId(curr);
                if(curr==1)
                    imageArea.setImageResource(R.drawable.puzzle1_l);
                else if(curr==2)
                    imageArea.setImageResource(R.drawable.puzzle2_l);
                else if(curr==3)
                    imageArea.setImageResource(R.drawable.puzzle3_l);
                break;
            case Configuration.ORIENTATION_PORTRAIT:
                navigation.setVisibility(View.VISIBLE);
                if(curr==1)
                    imageArea.setImageResource(R.drawable.puzzle1_p);
                else if(curr==2)
                    imageArea.setImageResource(R.drawable.puzzle2_p);
                else if(curr==3)
                    imageArea.setImageResource(R.drawable.puzzle3_p);
                break;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        inflater = getMenuInflater();
        inflater.inflate(R.menu.navigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_1:
                imageArea.setImageResource(R.drawable.puzzle1_l);
                curr = 1;
                return true;
            case R.id.nav_2:
                imageArea.setImageResource(R.drawable.puzzle2_l);
                curr = 2;
                return true;
            case R.id.nav_3:
                imageArea.setImageResource(R.drawable.puzzle3_l);
                curr = 3;
                return true;
            case R.id.nav_4:
                inputDialog();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void inputDialog() {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);

        builder.setTitle(R.string.input);

        LayoutInflater inflater = this.getLayoutInflater();
        mView = inflater.inflate(R.layout.input_age_layout, null);
        builder.setView(mView);

        builder.setPositiveButton(R.string.submit, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                editText = mView.findViewById(R.id.editText);
                if(editText.getText().toString().equals("143")){
                    triggerBasicNotification();
                } else {
                    Toast toast= Toast.makeText(getApplicationContext(), R.string.lose, Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL, 0, 50);
                    toast.show();
                }
            }
        });
        builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                //Log.d("LOGIN NOTIFICATION","Cancel");
            }
        });

        dialog = builder.create();
        dialog.show();
    }

    public void triggerBasicNotification(){
        createNotificationChannel();
        createBasicNotification();
    }

    private void createNotificationChannel() {
        //(1) In higher versions of Android, there is a need to create notification channels where
        //    notifications are grouped. Not all systems support this as it depends on the Android
        //    version to be used.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, getResources().getString(R.string.app_name), importance);
            channel.setDescription(getResources().getString(R.string.app_name));

            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    public void createBasicNotification(){
        //(2) Every notification is built using the Notification Builder
        NotificationCompat.Builder builder = new NotificationCompat.Builder(getApplicationContext(), CHANNEL_ID);

        //(3) Various notification attributes can be declared here. Note that ones that are important:
        builder.setSmallIcon(R.drawable.notification_icon);
        builder.setContentTitle(getResources().getString(R.string.app_name));
        builder.setContentText(getResources().getString(R.string.win));
        builder.setPriority(NotificationCompat.PRIORITY_DEFAULT);

        //(4) These attributes are still important though not required to execute
        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.notification_icon_big));
        builder.setAutoCancel(true);

        //(5) Notifications are run by calling a notification manager and calling the notify function
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(getApplicationContext());
        notificationManager.notify(notificationID, builder.build());
        notificationID++;
    }

}
