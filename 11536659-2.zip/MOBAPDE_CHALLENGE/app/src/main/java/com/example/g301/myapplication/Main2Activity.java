package com.example.g301.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Button rcode = findViewById(R.id.rcode);

        rcode.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Random rand = new Random();
                SharedPreferences.Editor preferenceEditor = getSharedPreferences("sharedPref", MODE_PRIVATE).edit();
                preferenceEditor.putInt("c1", rand.nextInt(6));
                preferenceEditor.putInt("c2", rand.nextInt(6));
                preferenceEditor.putInt("c3", rand.nextInt(6));
                preferenceEditor.putInt("att", 0);
                preferenceEditor.commit();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                Main2Activity.this.startActivity(intent);
                Main2Activity.this.finish();
            }
        });

        Button rattempt = findViewById(R.id.rattempt);

        rattempt.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                SharedPreferences.Editor preferenceEditor = getSharedPreferences("sharedPref", MODE_PRIVATE).edit();
                preferenceEditor.putInt("att", 0);
                preferenceEditor.commit();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                Main2Activity.this.startActivity(intent);
                Main2Activity.this.finish();
            }
        });
    }
}
