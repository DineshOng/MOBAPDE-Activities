package com.example.g301.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    //private ArrayList contacts;
    private LinearLayout linearLayout;
    private SharedPreferences sharedPref;
    private SharedPreferences.Editor editor;
    private contact user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPref = getPreferences(Context.MODE_PRIVATE);
        editor = sharedPref.edit();

        linearLayout = findViewById(R.id.lol);

        String u = sharedPref.getString("1$", "");
        linearLayout.addView(createNewTextView(u));

        linearLayout = (LinearLayout) findViewById(R.id.lol);
        TextView textView = new TextView(this);
        textView.setText("New text");

        user = null;

        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                EditText e1 = findViewById(R.id.name);
                EditText e2 = findViewById(R.id.number);
                if(!e1.getText().toString().equals("")||!e2.getText().toString().equals("")) {
                    linearLayout.addView(createNewTextView(e1.getText().toString() + ": " + e2.getText().toString()));
                    user = new contact(e1.getText().toString(), e2.getText().toString());
                }
            }
        });
    }

    @Override
    protected void onPause(){
        super.onPause();

        SharedPreferences sharedPref = getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putString("1$",user.getName()+": "+user.getNumber());
        editor.commit();
    }

    private TextView createNewTextView(String text) {
        final LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        final TextView textView = new TextView(this);
        textView.setLayoutParams(lparams);
        textView.setText(text);
        return textView;
    }
}
